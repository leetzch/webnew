<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_menu = $_POST['nama_menu'] ?? '';
    $harga = $_POST['harga'] ?? '';

    if (empty($nama_menu) || $harga === '') {
        // Redirect back with error or handle error appropriately
        header('Location: data_menu.php?error=empty_fields');
        exit();
    }

    // Prepare and execute insert statement
    $stmt = $conn->prepare("INSERT INTO menu (nama_menu, harga) VALUES (?, ?)");
    if ($stmt === false) {
        // Handle prepare error
        header('Location: data_menu.php?error=stmt_prepare_failed');
        exit();
    }
    $stmt->bind_param('sd', $nama_menu, $harga);

    if ($stmt->execute()) {
        $stmt->close();
        header('Location: data_menu.php?success=menu_added');
        exit();
    } else {
        // Handle execution error
        $stmt->close();
        header('Location: data_menu.php?error=stmt_execute_failed');
        exit();
    }
} else {
    // Invalid request method
    header('Location: data_menu.php');
    exit();
}
?>
