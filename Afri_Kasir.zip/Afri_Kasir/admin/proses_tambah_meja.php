<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nomor_meja = $_POST['nomor_meja'] ?? '';
    $kapasitas_meja = $_POST['kapasitas_meja'] ?? '';

    if (empty($nomor_meja) || empty($kapasitas_meja)) {
        // Redirect back with error or handle error appropriately
        header('Location: data_meja.php?error=empty_fields');
        exit();
    }

    // Prepare and execute insert statement
    $stmt = $conn->prepare("INSERT INTO meja (nomor_meja, kapasitas_meja) VALUES (?, ?)");
    if ($stmt === false) {
        // Handle prepare error
        header('Location: data_meja.php?error=stmt_prepare_failed');
        exit();
    }
    $stmt->bind_param('si', $nomor_meja, $kapasitas_meja);

    if ($stmt->execute()) {
        $stmt->close();
        header('Location: data_meja.php?success=meja_added');
        exit();
    } else {
        // Handle execution error
        $stmt->close();
        header('Location: data_meja.php?error=duplicate');
        exit();
    }
} else {
    // Invalid request method
    header('Location: data_meja.php');
    exit();
}
?>
