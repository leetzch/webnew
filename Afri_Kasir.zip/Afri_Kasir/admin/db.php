<?php
// Simple database connection script

$host = 'localhost'; // Change if needed
$db = 'afri_kasir'; // Change to your database name
$user = 'root'; // Change to your database user
$pass = ''; // Change to your database password

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
