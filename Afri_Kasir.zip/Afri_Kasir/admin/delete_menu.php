<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require 'db.php';

if (isset($_GET['id'])) {
    $id_menu = $_GET['id'];

    // Prepare and execute delete statement
    $stmt = $conn->prepare("DELETE FROM menu WHERE id_menu = ?");
    if ($stmt === false) {
        // Handle prepare error
        header('Location: data_menu.php?error=stmt_prepare_failed');
        exit();
    }
    $stmt->bind_param('i', $id_menu);

    if ($stmt->execute()) {
        $stmt->close();
        header('Location: data_menu.php?success=menu_deleted');
        exit();
    } else {
        // Handle execution error
        $stmt->close();
        header('Location: data_menu.php?error=stmt_execute_failed');
        exit();
    }
} else {
    // No id provided
    header('Location: data_menu.php?error=no_id');
    exit();
}
?>
