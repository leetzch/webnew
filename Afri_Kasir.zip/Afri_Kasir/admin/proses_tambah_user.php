<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? '';

    if (empty($username) || empty($password) || empty($role)) {
        // Redirect back with error or handle error appropriately
        header('Location: data_user.php?error=empty_fields');
        exit();
    }

    // Hash the password before storing
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Prepare and execute insert statement
    $stmt = $conn->prepare("INSERT INTO user (username, password, role) VALUES (?, ?, ?)");
    if ($stmt === false) {
        // Handle prepare error
        header('Location: data_user.php?error=stmt_prepare_failed');
        exit();
    }
    $stmt->bind_param('sss', $username, $hashed_password, $role);

    if ($stmt->execute()) {
        $stmt->close();
        header('Location: data_user.php?success=user_added');
        exit();
    } else {
        // Handle execution error
        $stmt->close();
        header('Location: data_user.php?error=stmt_execute_failed');
        exit();
    }
} else {
    // Invalid request method
    header('Location: data_user.php');
    exit();
}
?>
