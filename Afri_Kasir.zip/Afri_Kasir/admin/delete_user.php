<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require 'db.php';

if (isset($_GET['id'])) {
    $id_user = $_GET['id'];

    // Prepare and execute delete statement
    $stmt = $conn->prepare("DELETE FROM user WHERE id_user = ?");
    if ($stmt === false) {
        // Handle prepare error
        header('Location: data_user.php?error=stmt_prepare_failed');
        exit();
    }
    $stmt->bind_param('i', $id_user);

    if ($stmt->execute()) {
        $stmt->close();
        header('Location: data_user.php?success=user_deleted');
        exit();
    } else {
        // Handle execution error
        $stmt->close();
        header('Location: data_user.php?error=stmt_execute_failed');
        exit();
    }
} else {
    // No id provided
    header('Location: data_user.php?error=no_id_provided');
    exit();
}
?>
