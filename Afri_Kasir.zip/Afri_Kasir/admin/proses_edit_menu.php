<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_menu = $_POST['id_menu'] ?? '';
    $nama_menu = $_POST['nama_menu'] ?? '';
    $harga = $_POST['harga'] ?? '';

    if (empty($id_menu) || empty($nama_menu) || $harga === '') {
        // Redirect back with error or handle error appropriately
        header('Location: data_menu.php?error=empty_fields');
        exit();
    }

    // Prepare and execute update statement without stok
    $stmt = $conn->prepare("UPDATE menu SET nama_menu = ?, harga = ? WHERE id_menu = ?");
    if ($stmt === false) {
        // Handle prepare error
        header('Location: data_menu.php?error=stmt_prepare_failed');
        exit();
    }
    $stmt->bind_param('sdi', $nama_menu, $harga, $id_menu);

    if ($stmt->execute()) {
        $stmt->close();
        header('Location: data_menu.php?success=menu_edited');
        exit();
    } else {
        // Handle execution error
        $stmt->close();
        header('Location: data_menu.php?error=stmt_execute_failed');
        exit();
    }
} else {
    // Invalid request method
    header('Location: data_menu.php');
    exit();
}
?>
