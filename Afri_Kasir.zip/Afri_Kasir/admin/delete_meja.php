<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require 'db.php';

if (isset($_GET['id'])) {
    $id_meja = $_GET['id'];

    // Prepare and execute delete statement
    $stmt = $conn->prepare("DELETE FROM meja WHERE id_meja = ?");
    if ($stmt === false) {
        // Handle prepare error
        header('Location: data_meja.php?error=stmt_prepare_failed');
        exit();
    }
    $stmt->bind_param('i', $id_meja);

    if ($stmt->execute()) {
        $stmt->close();
        header('Location: data_meja.php?success=meja_deleted');
        exit();
    } else {
        // Handle execution error
        $stmt->close();
        header('Location: data_meja.php?error=stmt_execute_failed');
        exit();
    }
} else {
    // No id provided
    header('Location: data_meja.php?error=no_id_provided');
    exit();
}
?>
