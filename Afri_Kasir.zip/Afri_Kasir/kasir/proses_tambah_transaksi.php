  <?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_pesanan = $_POST['id_pesanan'] ?? null;
    $bayar = $_POST['bayar'] ?? null;
    $total_pesanan = $_POST['total_pesanan'];
    $uang = $_POST['uang'] ?? null;
    $status_transaksi = $_POST['status_transaksi'] ?? null;

    $tanggal_pesanan = date('Y-m-d H:i:s');


    // Cast to appropriate types
    $id_pesanan = (int)$id_pesanan;
    $bayar = (float)$bayar;
    $uang = (float)$uang;
    $status_transaksi = trim($status_transaksi);

    if (!$id_pesanan || !$bayar || !$status_transaksi) {
        $_SESSION['error'] = 'ID Pesanan, Bayar, and Status Transaksi are required.';
        header('Location: data_transaksi.php');
        exit();
    }

    // Calculate total from database
    $stmt = $conn->prepare("SELECT SUM(dp.jumlah) FROM detail_pesanan dp WHERE dp.id_pesanan = ?");
    $stmt->bind_param('i', $id_pesanan);
    $stmt->execute();
    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();

    if ($total === null) {
        $_SESSION['error'] = 'Failed to calculate total for pesanan.';
        header('Location: data_transaksi.php');
        exit();
    }

    // Validate bayar is a positive number
    if (!is_numeric($bayar) || $bayar < 0) {
        $_SESSION['error'] = 'Bayar must be a positive number.';
        header('Location: data_transaksi.php');
        exit();
    }

    // Validate status_transaksi value
    $valid_statuses = ['belum dibayar', 'lunas',];
    if (!in_array($status_transaksi, $valid_statuses)) {
        $_SESSION['error'] = 'Status Transaksi tidak valid.';
        header('Location: data_transaksi.php');
        exit();
    }

    if($uang < $bayar){
        echo "<script>
            alert('Transaksi Gagal, Uang Kurang!');
            window.location.href = 'data_transaksi.php';
        </script>";
        exit();
    }
    
    // Check if the pesanan exists and status is 'Selesai'
    $stmt = $conn->prepare("SELECT status_pesanan FROM pesanan WHERE id_pesanan = ?");
    $stmt->bind_param('i', $id_pesanan);
    $stmt->execute();
    $stmt->bind_result($status_pesanan);
    if (!$stmt->fetch() || $status_pesanan !== 'Selesai') {
        $stmt->close();
        $_SESSION['error'] = 'Pesanan not found or not completed.';
        header('Location: data_transaksi.php');
        exit();
    }
    $stmt->close();

    // Check if a transaksi already exists for this pesanan
    $stmt = $conn->prepare("SELECT id_transaksi FROM transaksi WHERE id_pesanan = ?");
    $stmt->bind_param('i', $id_pesanan);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $stmt->close();
        $_SESSION['error'] = 'Transaksi for this pesanan already exists.';
        header('Location: data_transaksi.php');
        exit();
    }
    $stmt->close();

    // Insert new transaksi
    $stmt = $conn->prepare("INSERT INTO transaksi (id_pesanan, total, bayar, uang, status_transaksi, tanggal_transaksi) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param('iiddss', $id_pesanan, $total_pesanan, $bayar, $uang, $status_transaksi, $tanggal_pesanan);
    if ($stmt->execute()) {
        $_SESSION['success'] = 'Transaksi berhasil ditambahkan.';
    } else {
        $_SESSION['error'] = 'Gagal menambahkan transaksi.';
    }
    $stmt->close();

    header('Location: data_transaksi.php');
    exit();
} else {
    header('Location: data_transaksi.php');
    exit();
}
?>
