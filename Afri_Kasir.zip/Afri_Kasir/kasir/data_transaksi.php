<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}
require 'db.php';


function formatRupiah($angka){
    $angka *= 1000; // Tambah tiga nol di belakang
    $hasil = "Rp " . number_format($angka, 0, ',', '.');
    return $hasil;
}


$user_id = $_SESSION['user_id'];
$username = 'Afri Maulizuardi'; // default username

$stmt = $conn->prepare('SELECT username FROM user WHERE id_user = ?');
$stmt->bind_param('i', $user_id);
$stmt->execute();
$stmt->bind_result($db_username);
if ($stmt->fetch()) {
    $username = $db_username;
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Data Transaksi | AfriKasir - LSP</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../assets/images/favicon.ico">
    <link href="../assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="../assets/css/app.min.css" rel="stylesheet" type="text/css" id="light-style" />
    <link href="../assets/css/app-dark.min.css" rel="stylesheet" type="text/css" id="dark-style" />
</head>

<body class="loading" data-layout-config='{"leftSideBarTheme":"dark","layoutBoxed":false,"leftSidebarCondensed":false,"leftSidebarScrollable":false,"darkMode":false,"showRightSidebarOnStart":true}'>
    <div class="wrapper">
        <div class="leftside-menu">
            <a href="index.php" class="logo text-center logo-light">
                <span class="logo-lg">
                    <img src="../assets/images/logo.png" alt="" height="16" />
                </span>
                <span class="logo-sm">
                    <img src="../assets/images/logo_sm.png" alt="" height="16" />
                </span>
            </a>
            <div class="h-100" id="leftside-menu-container" data-simplebar="">

                <!--- Sidemenu -->
                <ul class="side-nav">

                    <li class="side-nav-title side-nav-item">Navigation</li>

                    <li class="side-nav-item">
                        <a data-bs-toggle="collapse" href="index.php" aria-expanded="false" aria-controls="sidebarDashboards" class="side-nav-link">
                            <i class="uil-home-alt"></i>
                            <span class="badge bg-success float-end">4</span>
                            <span> Dashboards </span>
                        </a>
                        
                    </li>

                    <li class="side-nav-title side-nav-item">Apps</li>
                    <li class="side-nav-item">
                        <a href="data_transaksi.php" class="side-nav-link">
                            <i class="uil-calender"></i>
                            <span> Data Transaksi </span>
                        </a>
                    </li>
                    
                    <li class="side-nav-item">
                        <a href="logout.php" class="side-nav-link">
                            <i class="mdi mdi-logout me-1"></i>
                            <span> Log Out </span>
                        </a>
                    </li>
                </ul>
                <div class="clearfix"></div>
            </div>
        </div>

        <div class="content-page">
            <div class="content">
                <div class="navbar-custom">
                    <ul class="list-unstyled topbar-menu float-end mb-0">
                        <li class="dropdown notification-list d-lg-none">
                            <a class="nav-link dropdown-toggle arrow-none" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                <i class="dripicons-search noti-icon"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-animated dropdown-lg p-0">
                                <form class="p-3">
                                    <input type="text" class="form-control" placeholder="Search ..." aria-label="Recipient's username" />
                                </form>
                            </div>
                        </li>
                        <li class="dropdown notification-list">
                            <a class="nav-link dropdown-toggle nav-user arrow-none me-0" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                <span class="account-user-avatar">
                                    <img src="../assets/images/users/avatar-1.jpg" alt="user-image" class="rounded-circle" />
                                </span>
                                <span>
                                    <span class="account-user-name"><?php echo htmlspecialchars($username ?? ''); ?></span>
                                    <span class="account-position">Founder</span>
                                </span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end dropdown-menu-animated topbar-dropdown-menu profile-dropdown">
                                <div class=" dropdown-header noti-title">
                                    <h6 class="text-overflow m-0">Welcome !</h6>
                                </div>
                                <a href="logout.php" class="dropdown-item notify-item">
                                    <i class="mdi mdi-logout me-1"></i>
                                    <span>Logout</span>
                                </a>
                            </div>
                        </li>
                    </ul>
                </div>

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <h4 class="page-title">Data Transaksi</h4>
                            </div>
                        </div>
                    </div>

                            <button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addTransaksiModal">
                                Tambah Transaksi
                            </button>

                            <!-- Modal Tambah Transaksi -->
                            <div class="modal fade" id="addTransaksiModal" tabindex="-1" aria-labelledby="addTransaksiModalLabel" aria-hidden="true">
                              <div class="modal-dialog">
                                <div class="modal-content">
                                  <form method="POST" action="proses_tambah_transaksi.php">
                                    <div class="modal-header">
                                      <h5 class="modal-title" id="addTransaksiModalLabel">Tambah Transaksi</h5>
                                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                    <div class="mb-3">
                                        <label for="id_pesanan" class="form-label">Pilih Pesanan (Status Selesai)</label>
                                        <select name="id_pesanan" id="id_pesanan" class="form-select" required>
                                            <option value="">-- Pilih Pesanan --</option>
                                            <?php
                                            $pesanan_query = "SELECT p.id_pesanan, GROUP_CONCAT(m.nama_menu SEPARATOR ', ') AS nama_pesanan, p.jumlah AS total_pesanan, SUM(dp.subtotal) AS bayar_total
                                                              FROM pesanan p
                                                              INNER JOIN detail_pesanan dp ON p.id_pesanan = dp.id_pesanan
                                                              INNER JOIN menu m ON dp.id_menu = m.id_menu
                                                              LEFT JOIN transaksi t ON p.id_pesanan = t.id_pesanan
                                                              WHERE p.status_pesanan = 'Selesai' AND t.id_transaksi IS NULL
                                                              GROUP BY p.id_pesanan";
                                            $pesanan_result = $conn->query($pesanan_query);
                                            $pesanan_list = [];
                                            if ($pesanan_result) {
                                                while ($row = $pesanan_result->fetch_assoc()) {
                                                    $pesanan_list[] = $row;
                                                    echo "<option value='" . htmlspecialchars($row['id_pesanan']) . "'>" . htmlspecialchars($row['nama_pesanan']) . " (ID: " . htmlspecialchars($row['id_pesanan']) . ")</option>";
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="total_pesanan" class="form-label">Total Pesanan</label>
                                        <input type="text" id="total_pesanan" name="total_pesanan" class="form-control" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="bayar" class="form-label">Bayar</label>
                                        <input type="number" step="0.01" name="bayar" id="bayar" class="form-control" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="uang" class="form-label">Uang</label>
                                        <input type="number" step="0.01" name="uang" id="uang" class="form-control" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="status_transaksi" class="form-label">Status Transaksi</label>
                                        <select name="status_transaksi" id="status_transaksi" class="form-select" required>
                                            <option value="belum dibayar">Belum Dibayar</option>
                                            <option value="lunas">Lunas</option>
                                        </select>
                                    </div>
                                    </div>
                                    <div class="modal-footer">
                                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                      <button type="submit" class="btn btn-primary">Tambah Transaksi</button>
                                    </div>
                                  </form>
                                </div>
                              </div>
                            </div>
                            
                            <!-- Modal Edit Transaksi -->
<div class="modal fade" id="editTransaksiModal" tabindex="-1" aria-labelledby="editTransaksiModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<form method="POST" action="proses_edit_transaksi.php">
<div class="modal-header">
<h5 class="modal-title" id="editTransaksiModalLabel">Edit Transaksi</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<input type="hidden" name="id_transaksi" id="edit_id_transaksi">
<div class="mb-3">
<label class="form-label">Pesanan</label>
<input type="text" id="edit_nama_pesanan" class="form-control" readonly>
<input type="hidden" name="id_pesanan" id="edit_id_pesanan">
</div>
<div class="mb-3">
<label for="edit_total_pesanan" class="form-label">Total Pesanan</label>
<input type="text" id="edit_total_pesanan" name="total_pesanan" class="form-control" readonly>
</div>
<div class="mb-3">
<label for="edit_bayar" class="form-label">Bayar</label>
<input type="number" step="0.01" name="bayar" id="edit_bayar" class="form-control" required>
</div>
<div class="mb-3">
<label for="edit_uang" class="form-label">Uang</label>
<input type="number" step="0.01" name="uang" id="edit_uang" class="form-control" required>
</div>
<div class="mb-3">
<label for="edit_status_transaksi" class="form-label">Status Transaksi</label>
<select name="status_transaksi" id="edit_status_transaksi" class="form-select" required>
<option value="belum dibayar">Belum Dibayar</option>
<option value="lunas">Lunas</option>
</select>
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
<button type="submit" class="btn btn-primary">Update Transaksi</button>
</div>
</form>
</div>
</div>
</div>

                            

                            

                            <table id="transaksi-datatable" class="table table-bordered table-striped dt-responsive nowrap w-100">
                                <thead>
                                    <tr>
                                        <th>ID Pesanan</th>
                                        <th>Nama Pesanan</th>
                                        <th>Total Pesanan</th>
                                        <th>Uang</th>
                                        <th>Bayar</th>
                                        <th>Kembalian</th>
                                        <th>Status Transaksi</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        
                                    $query = "SELECT p.id_pesanan, p.status_pesanan, t.id_transaksi, GROUP_CONCAT(m.nama_menu SEPARATOR ', ') AS nama_pesanan, p.jumlah AS total_pesanan, t.bayar, t.uang, t.status_transaksi
                                              FROM pesanan p
                                              INNER JOIN detail_pesanan dp ON p.id_pesanan = dp.id_pesanan
                                              INNER JOIN menu m ON dp.id_menu = m.id_menu
                                              INNER JOIN transaksi t ON p.id_pesanan = t.id_pesanan
                                              WHERE p.status_pesanan = 'Selesai'
                                              GROUP BY p.id_pesanan, t.id_transaksi, t.bayar, t.uang, t.status_transaksi";
                                    $result = $conn->query($query);
                                    if ($result && $result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $kembalian = $row['uang'] - $row['bayar'];
                                            echo "<tr>";
                                            echo "<td>" . htmlspecialchars($row['id_pesanan']) . "</td>";
                                            echo "<td>" . htmlspecialchars($row['nama_pesanan']) . "</td>";
                                            echo "<td>" . htmlspecialchars($row['total_pesanan']) . "</td>";
                                            echo "<td>" . htmlspecialchars(formatRupiah($row['uang'])) . "</td>";
                                            echo "<td>" . htmlspecialchars(formatRupiah($row['bayar'])) . "</td>";
                                            echo "<td>" . htmlspecialchars(formatRupiah($kembalian)) . "</td>";
                                            echo "<td>" . htmlspecialchars($row['status_transaksi']) . "</td>";
                                            echo "<td>";
                                            echo "<button class='btn btn-sm btn-warning me-1 edit-transaksi-btn' data-id='" . htmlspecialchars($row['id_transaksi']) . "' data-id_pesanan='" . htmlspecialchars($row['id_pesanan']) . "' data-nama_pesanan='" . htmlspecialchars($row['nama_pesanan']) . "' data-total_pesanan='" . htmlspecialchars($row['total_pesanan']) . "' data-bayar='" . htmlspecialchars($row['bayar']) . "' data-uang='" . htmlspecialchars($row['uang']) . "' data-status_transaksi='" . htmlspecialchars($row['status_transaksi']) . "'>Edit</button>";
                                            echo "<a href='delete_transaksi.php?id=" . urlencode($row['id_transaksi']) . "' class='btn btn-sm btn-danger me-1' onclick=\"return confirm('Are you sure you want to delete this transaction?');\">Delete</a>";
                                            echo "<a href='data_transaksi_detail.php?id=" . urlencode($row['id_pesanan']) . "' target='_blank' class='btn btn-sm btn-info'>Generate Laporan</a>";
                                            echo "</td>";
                                            echo "</tr>";
                                        }
                                    } else {
                                        echo "<tr><td colspan='8'>No data found</td></tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                </div>
            </div>
        </div>
    </div>

    <div class="rightbar-overlay"></div>

    <script src="../assets/js/vendor.min.js"></script>
    <script src="../assets/js/app.min.js"></script>
    <script>
        const pesananData = <?php echo json_encode($pesanan_list); ?>;
        const selectPesanan = document.getElementById('id_pesanan');
        const bayarInput = document.getElementById('bayar');
        const totalPesananInput = document.getElementById('total_pesanan');

        selectPesanan.addEventListener('change', function() {
            const selectedId = this.value;
            const pesanan = pesananData.find(p => p.id_pesanan === selectedId);
            if (pesanan) {
                totalPesananInput.value = pesanan.total_pesanan;
                bayarInput.value = pesanan.bayar_total;
                bayarInput.setAttribute('value', pesanan.bayar_total);
            } else {
                totalPesananInput.value = '';
                bayarInput.value = '';
                bayarInput.removeAttribute('value');
            }
        });

        // Also update bayar input when modal is shown and a pesanan is selected
        const addTransaksiModal = document.getElementById('addTransaksiModal');
        addTransaksiModal.addEventListener('show.bs.modal', function () {
            const selectedId = selectPesanan.value;
            const pesanan = pesananData.find(p => p.id_pesanan === selectedId);
            if (pesanan) {
                totalPesananInput.value = pesanan.total_pesanan;
                bayarInput.value = pesanan.bayar_total;
                bayarInput.setAttribute('value', pesanan.bayar_total);
            } else {
                totalPesananInput.value = '';
                bayarInput.value = '';
                bayarInput.removeAttribute('value');
            }
        });

        // Edit Transaksi Modal Activation
        document.querySelectorAll('.edit-transaksi-btn').forEach(button => {
            button.addEventListener('click', function () {
                const idTransaksi = this.getAttribute('data-id');
                const idPesanan = this.getAttribute('data-id_pesanan');
                const namaPesanan = this.getAttribute('data-nama_pesanan');
                const totalPesanan = this.getAttribute('data-total_pesanan');
                const bayar = this.getAttribute('data-bayar');
                const uang = this.getAttribute('data-uang');
                const statusTransaksi = this.getAttribute('data-status_transaksi');

                // Set values in the edit modal form
                document.getElementById('edit_id_transaksi').value = idTransaksi;
                document.getElementById('edit_id_pesanan').value = idPesanan;
                document.getElementById('edit_nama_pesanan').value = namaPesanan;
                document.getElementById('edit_total_pesanan').value = totalPesanan;

                document.getElementById('edit_bayar').value = bayar;
                document.getElementById('edit_uang').value = uang;
                document.getElementById('edit_status_transaksi').value = statusTransaksi;

                // Show the edit modal
                var editModal = new bootstrap.Modal(document.getElementById('editTransaksiModal'));
                editModal.show();
            });
        });
    </script>

<div class="rightbar-overlay"></div>
    <!-- /End-bar -->

    <!-- bundle -->
    <!-- third party js -->
    <script src="../assets/js/vendor/apexcharts.min.js"></script>
    <script src="../assets/js/vendor/jquery-jvectormap-1.2.2.min.js"></script>
    <script src="../assets/js/vendor/jquery-jvectormap-world-mill-en.js"></script>
    <!-- third party js ends -->

    <!-- demo app -->
    <script src="../assets/js/pages/demo.dashboard.js"></script>
    <!-- end demo js-->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.body.classList.remove('loading');
        });
    </script>
</body>
</html>




