<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}
require 'db.php';

if (!isset($_GET['id'])) {
    header('Location: data_transaksi.php');
    exit();
}

$id_transaksi = $_GET['id'];

// Delete the transaction record
$stmt = $conn->prepare("DELETE FROM transaksi WHERE id_transaksi = ?");
$stmt->bind_param("i", $id_transaksi);
if ($stmt->execute()) {
    $stmt->close();
    header('Location: data_transaksi.php?msg=deleted');
    exit();
} else {
    $stmt->close();
    header('Location: data_transaksi.php?msg=error');
    exit();
}
?>
