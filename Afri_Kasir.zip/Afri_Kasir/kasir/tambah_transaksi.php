ma<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}
require 'db.php';

$user_id = $_SESSION['user_id'];
$username = 'Afri Maulizuardi'; // default username

// Fetch username
$stmt = $conn->prepare('SELECT username FROM user WHERE id_user = ?');
$stmt->bind_param('i', $user_id);
$stmt->execute();
$stmt->bind_result($db_username);
if ($stmt->fetch()) {
    $username = $db_username;
}
$stmt->close();



// Fetch pesanan with status 'Selesai' and no transaksi yet, including total price
$query = "SELECT p.id_pesanan, GROUP_CONCAT(m.nama_menu SEPARATOR ', ') AS nama_pesanan, SUM(dp.subtotal) AS total_pesanan
          FROM pesanan p
          INNER JOIN detail_pesanan dp ON p.id_pesanan = dp.id_pesanan
          INNER JOIN menu m ON dp.id_menu = m.id_menu
          LEFT JOIN transaksi t ON p.id_pesanan = t.id_pesanan
          WHERE p.status_pesanan = 'Selesai' AND t.id_transaksi IS NULL
          GROUP BY p.id_pesanan";

$result = $conn->query($query);
$pesanan_list = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $pesanan_list[] = $row;
    }
}
// Debug output to verify total_pesanan values
echo '<pre>Pesanan List: ';
print_r($pesanan_list);
echo '</pre>';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Tambah Transaksi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../assets/css/app.min.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <div class="container mt-4">
        <h2>Tambah Transaksi</h2>
        <?php if ($message): ?>
            <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        <form method="POST" action="proses_tambah_transaksi.php" id="transaksiForm">
            <div class="mb-3">
                <label for="id_pesanan" class="form-label">Pilih Pesanan (Status Selesai)</label>
                <select name="id_pesanan" id="id_pesanan" class="form-select" required>
                    <option value="">-- Pilih Pesanan --</option>
                    <?php foreach ($pesanan_list as $pesanan): ?>
                        <option value="<?php echo htmlspecialchars($pesanan['id_pesanan']); ?>">
                            <?php echo htmlspecialchars($pesanan['nama_pesanan']); ?> (ID: <?php echo htmlspecialchars($pesanan['id_pesanan']); ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="bayar" class="form-label">Bayar</label>
                <input type="number" step="0.01" name="bayar" id="bayar" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="uang" class="form-label">Uang</label>
                <input type="number" step="0.01" name="uang" id="uang" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="status_transaksi" class="form-label">Status Transaksi</label>
                <select name="status_transaksi" id="status_transaksi" class="form-select" required>
                    <option value="">-- Pilih Status --</option>
                    <option value="Pending">Pending</option>
                    <option value="Completed">Completed</option>
                    <option value="Cancelled">Cancelled</option>
                </select>
            </div>
            <input type="hidden" name="total_pesanan" id="total_pesanan" value="">
            <button type="submit" class="btn btn-primary">Tambah Transaksi</button>
            <a href="data_transaksi.php" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
    <script>
        const pesananData = <?php echo json_encode($pesanan_list); ?>;
        const selectPesanan = document.getElementById('id_pesanan');
        const bayarInput = document.getElementById('bayar');
        const uangInput = document.getElementById('uang');
        const totalInput = document.getElementById('total_pesanan');
        const form = document.getElementById('transaksiForm');

        function formatCurrency(amount) {
            return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(amount);
        }

        selectPesanan.addEventListener('change', function() {
            const selectedId = this.value;
            const pesanan = pesananData.find(p => p.id_pesanan == selectedId);
            if (pesanan) {
                bayarInput.value = pesanan.total_pesanan;
                uangInput.value = '';
                totalInput.value = pesanan.total_pesanan;
                // Optionally display formatted currency somewhere if needed
                // e.g., document.getElementById('bayarFormatted').textContent = formatCurrency(pesanan.total_pesanan);
            } else {
                bayarInput.value = '';
                uangInput.value = '';
                totalInput.value = '';
                // document.getElementById('bayarFormatted').textContent = '';
            }
        });

        form.addEventListener('submit', function(event) {
            if (!totalInput.value) {
                const selectedId = selectPesanan.value;
                const pesanan = pesananData.find(p => p.id_pesanan == selectedId);
                if (pesanan) {
                    totalInput.value = pesanan.total_pesanan;
                }
            }
        });
    </script>
</body>
</html>
