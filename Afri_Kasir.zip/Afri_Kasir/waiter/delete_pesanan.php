<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['id'])) {
    $id_pesanan = $_GET['id'];

    // Start a transaction
    $conn->begin_transaction();

    try {
        // Delete detail_pesanan entries first due to foreign key constraints
        $stmt_detail = $conn->prepare("DELETE FROM detail_pesanan WHERE id_pesanan = ?");
        $stmt_detail->bind_param("i", $id_pesanan);
        $stmt_detail->execute();
        $stmt_detail->close();

        // Delete the pesanan entry
        $stmt_pesanan = $conn->prepare("DELETE FROM pesanan WHERE id_pesanan = ?");
        $stmt_pesanan->bind_param("i", $id_pesanan);
        $stmt_pesanan->execute();
        $stmt_pesanan->close();

        // Commit the transaction
        $conn->commit();

        header("Location: data_pesanan.php?success=pesanan_deleted");
        exit();
    } catch (Exception $e) {
        // Rollback the transaction in case of error
        $conn->rollback();
        header("Location: data_pesanan.php?error=" . urlencode($e->getMessage()));
        exit();
    }
} else {
    header("Location: data_pesanan.php");
    exit();
}
?>
