<?php
header('Content-Type: application/json');
require 'db.php';

if (!isset($_GET['id'])) {
    echo json_encode(['error' => 'Missing order ID']);
    exit;
}

$id_pesanan = (int)$_GET['id'];

$stmt = $conn->prepare("SELECT id_menu, jumlah FROM detail_pesanan WHERE id_pesanan = ?");
$stmt->bind_param("i", $id_pesanan);
$stmt->execute();
$result = $stmt->get_result();

$menu_items = [];
while ($row = $result->fetch_assoc()) {
    $menu_items[] = [
        'id_menu' => $row['id_menu'],
        'jumlah' => (int)$row['jumlah']
    ];
}

echo json_encode(['menu_items' => $menu_items]);
?>
