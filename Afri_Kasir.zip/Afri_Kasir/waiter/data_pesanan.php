<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}
require 'db.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

$user_id = $_SESSION['user_id'];

// Fetch meja data for dropdown
$meja_list = [];
$meja_result = $conn->query("SELECT nomor_meja FROM meja ORDER BY nomor_meja ASC");
if ($meja_result && $meja_result->num_rows > 0) {
    while ($row = $meja_result->fetch_assoc()) {
        $meja_list[] = $row['nomor_meja'];
    }
}

// Fetch pelanggan data for dropdown
$pelanggan_list = [];
$pelanggan_result = $conn->query("SELECT nama_pelanggan FROM pelanggan ORDER BY nama_pelanggan ASC");
if ($pelanggan_result && $pelanggan_result->num_rows > 0) {
    while ($row = $pelanggan_result->fetch_assoc()) {
        $pelanggan_list[] = $row['nama_pelanggan'];
    }
}

$stmt = $conn->prepare('SELECT username FROM user WHERE id_user = ?');
$stmt->bind_param('i', $user_id);
$stmt->execute();
$stmt->bind_result($db_username);
if ($stmt->fetch()) {
    $username = $db_username;
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Data Pesanan | AfriKasir - LSP</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="shortcut icon" href="../assets/images/favicon.ico">
    <link href="../assets/css/vendor/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css">
    <link href="../assets/css/icons.min.css" rel="stylesheet" type="text/css">
    <link href="../assets/css/app.min.css" rel="stylesheet" type="text/css" id="light-style">
    <link href="../assets/css/app-dark.min.css" rel="stylesheet" type="text/css" id="dark-style">
</head>

<body class="loading" data-layout-config='{"leftSideBarTheme":"dark","layoutBoxed":false, "leftSidebarCondensed":false, "leftSidebarScrollable":false,"darkMode":false, "showRightSidebarOnStart": true}'>
    <div class="wrapper">
        <div class="leftside-menu">
            <a href="index.php" class="logo text-center logo-light">
                <span class="logo-lg">
                    <img src="../assets/images/logo.png" alt="" height="16">
                </span>
                <span class="logo-sm">
                    <img src="../assets/images/logo_sm.png" alt="" height="16">
                </span>
            </a>
            <div class="h-100" id="leftside-menu-container" data-simplebar="">
                <ul class="side-nav">
                    <li class="side-nav-title side-nav-item">Navigation</li>
                    <li class="side-nav-item">
                        <a data-bs-toggle="collapse" href="#sidebarDashboards" aria-expanded="false" aria-controls="sidebarDashboards" class="side-nav-link">
                            <i class="uil-home-alt"></i>
                            <span class="badge bg-success float-end">4</span>
                            <span> Dashboards </span>
                        </a>
                    </li>
                    <li class="side-nav-title side-nav-item">Apps</li>
                    <li class="side-nav-item">
                        <a href="data_pelanggan.php" class="side-nav-link">
                            <i class="uil-calender"></i>
                            <span> Data Pelanggan </span>
                        </a>
                    </li>
                    <li class="side-nav-item">
                        <a href="data_pesanan.php" class="side-nav-link">
                            <i class="uil-comments-alt"></i>
                            <span> Data Pesanan </span>
                        </a>
                    </li>
                    <li class="side-nav-item">
                        <a href="data_menu.php" class="side-nav-link">
                            <i class="uil-comments-alt"></i>
                            <span> Data Menu </span>
                        </a>
                    </li>
                    <li class="side-nav-item">
                        <a href="logout.php" class="side-nav-link">
                            <i class="mdi mdi-logout me-1"></i>
                            <span> Log Out </span>
                        </a>
                    </li>
                </ul>
                <div class="clearfix"></div>
            </div>
        </div>

        <div class="content-page">
            <div class="content">
                <div class="navbar-custom">
                    <ul class="list-unstyled topbar-menu float-end mb-0">
                        <li class="dropdown notification-list d-lg-none">
                            <a class="nav-link dropdown-toggle arrow-none" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                <i class="dripicons-search noti-icon"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-animated dropdown-lg p-0">
                                <form class="p-3">
                                    <input type="text" class="form-control" placeholder="Search ..." aria-label="Recipient's username">
                                </form>
                            </div>
                        </li>
                        <li class="dropdown notification-list">
                            <a class="nav-link dropdown-toggle nav-user arrow-none me-0" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                <span class="account-user-avatar"> 
                                    <img src="../assets/images/users/avatar-1.jpg" alt="user-image" class="rounded-circle">
                                </span>
                                <span>
                                    <span class="account-user-name"><?php echo htmlspecialchars($username ?? ''); ?></span>
                                    <span class="account-position">Founder</span>
                                </span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end dropdown-menu-animated topbar-dropdown-menu profile-dropdown">
                                <div class=" dropdown-header noti-title">
                                    <h6 class="text-overflow m-0">Welcome !</h6>
                                </div>
                                <a href="logout.php" class="dropdown-item notify-item">
                                    <i class="mdi mdi-logout me-1"></i>
                                    <span>Logout</span>
                                </a>
                            </div>
                        </li>
                    </ul>
                </div>

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <h4 class="page-title">Dashboard</h4>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addPesananModal">
                            Tambah Pesanan
                        </button>
                    </div>

                    <!-- Modal Tambah Pesanan -->
                    <div class="modal fade" id="addPesananModal" tabindex="-1" aria-labelledby="addPesananModalLabel" aria-hidden="true">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <form action="proses_tambah_pesanan.php" method="POST">
                            <div class="modal-header">
                              <h5 class="modal-title" id="addPesananModalLabel">Tambah Pesanan</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                              <div class="mb-3">
                                <label for="nomor_meja" class="form-label">Nomor Meja</label>
                                <select class="form-select" id="nomor_meja" name="nomor_meja" required>
                                    <option value="" disabled selected>Pilih Nomor Meja</option>
                                    <?php foreach ($meja_list as $nomor_meja_option): ?>
                                        <option value="<?php echo htmlspecialchars($nomor_meja_option); ?>"><?php echo htmlspecialchars($nomor_meja_option); ?></option>
                                    <?php endforeach; ?>
                                </select>
                              </div>
                              <div class="mb-3">
                                <label for="nama_pelanggan" class="form-label">Nama Pelanggan</label>
                                <select class="form-select" id="nama_pelanggan" name="nama_pelanggan" required>
                                    <option value="" disabled selected>Pilih Nama Pelanggan</option>
                                    <?php foreach ($pelanggan_list as $nama_pelanggan_option): ?>
                                        <option value="<?php echo htmlspecialchars($nama_pelanggan_option); ?>"><?php echo htmlspecialchars($nama_pelanggan_option); ?></option>
                                    <?php endforeach; ?>
                                </select>
                              </div>
                              <div class="mb-3">
                                <label class="form-label">Pilih Menu dan Jumlah</label>
                                <?php
                                $menu_query = "SELECT id_menu, nama_menu FROM menu";
                                $menu_result = $conn->query($menu_query);
                                if ($menu_result && $menu_result->num_rows > 0) {
                                    while ($menu_row = $menu_result->fetch_assoc()) {
                                        $id_menu = htmlspecialchars($menu_row['id_menu']);
                                        $nama_menu = htmlspecialchars($menu_row['nama_menu']);
                                        echo "<div class='input-group mb-2'>";
                                        echo "<div class='input-group-text'>";
                                        echo "<input type='checkbox' class='form-check-input mt-0' name='menu_items[]' value='$id_menu'>";
                                        echo "</div>";
                                        echo "<input type='text' class='form-control' value='$nama_menu' readonly>";
                                        echo "<input type='number' class='form-control' name='jumlah[$id_menu]' min='1' value='1' placeholder='Jumlah'>";
                                        echo "</div>";
                                    }
                                } else {
                                    echo "<p>No menu available</p>";
                                }
                                ?>
                              </div>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-primary">Save</button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>

                    <div class="tab-content">
                        <div class="tab-pane show active" id="basic-datatable-preview">
                            <table id="basic-datatable" class="table dt-responsive nowrap w-100">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Meja</th>
                                        <th>Pelanggan</th>
                                        <th>User</th>
                                        <th>Nama Menu</th>
                                        <th>Jumlah</th>
                                        <th>Total Harga</th>
                                        <th>Status Pesanan</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                $query = "SELECT p.id_pesanan, m.nomor_meja, pl.nama_pelanggan, u.username, GROUP_CONCAT(menu.nama_menu SEPARATOR ', ') AS nama_menu, p.jumlah, SUM(dp.subtotal) AS total_harga, p.status_pesanan 
                                          FROM pesanan p 
                                          INNER JOIN meja m ON p.id_meja = m.id_meja 
                                          INNER JOIN pelanggan pl ON p.id_pelanggan = pl.id_pelanggan 
                                          INNER JOIN detail_pesanan dp ON p.id_pesanan = dp.id_pesanan 
                                          INNER JOIN menu ON dp.id_menu = menu.id_menu
                                          INNER JOIN user u ON p.id_user = u.id_user
                                          GROUP BY p.id_pesanan, m.nomor_meja, pl.nama_pelanggan, u.username, p.jumlah, p.status_pesanan";
                                $result = $conn->query($query);
                                if ($result && $result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td>" . htmlspecialchars($row['id_pesanan'] ?? '') . "</td>";
                                        echo "<td>" . htmlspecialchars($row['nomor_meja'] ?? '') . "</td>";
                                        echo "<td>" . htmlspecialchars($row['nama_pelanggan'] ?? '') . "</td>";
                                        echo "<td>" . htmlspecialchars($row['username'] ?? '') . "</td>";
                                        echo "<td>" . htmlspecialchars($row['nama_menu'] ?? '') . "</td>";
                                        echo "<td>" . htmlspecialchars($row['jumlah'] ?? '') . "</td>";
                                        echo "<td>" . htmlspecialchars($row['total_harga'] ?? '') . "</td>";
                                        echo "<td>" . htmlspecialchars($row['status_pesanan'] ?? '') . "</td>";
echo "<td>";
echo "<button type='button' class='btn btn-sm btn-primary me-1 edit-btn' data-id='" . htmlspecialchars($row['id_pesanan'] ?? '') . "' data-nomor-meja='" . htmlspecialchars($row['nomor_meja'] ?? '') . "' data-nama-pelanggan='" . htmlspecialchars($row['nama_pelanggan'] ?? '') . "' data-status-pesanan='" . htmlspecialchars($row['status_pesanan'] ?? '') . "'>Edit</button>";
echo "<a href='delete_pesanan.php?id=" . urlencode($row['id_pesanan'] ?? '') . "' class='btn btn-sm btn-danger me-1' onclick=\"return confirm('Are you sure you want to delete this item?');\">Hapus</a>";
echo "<a href='../waiter/data_pesanan_detail.php?id=" . urlencode($row['id_pesanan'] ?? '') . "' target='_blank' class='btn btn-sm btn-info'>Generate Laporan</a>";
echo "</td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='9'>No data found</td></tr>";
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="rightbar-overlay"></div>
    <!-- /End-bar -->

    <!-- Modal Edit Pesanan -->
    <div class="modal fade" id="editPesananModal" tabindex="-1" aria-labelledby="editPesananModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="proses_edit_pesanan.php" method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editPesananModalLabel">Edit Pesanan</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" id="edit_id_pesanan" name="id_pesanan">
                        <div class="mb-3">
                            <label for="edit_nomor_meja" class="form-label">Nomor Meja</label>
                            <input type="text" class="form-control" id="edit_nomor_meja" name="nomor_meja" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_nama_pelanggan" class="form-label">Nama Pelanggan</label>
                            <input type="text" class="form-control" id="edit_nama_pelanggan" name="nama_pelanggan" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_status_pesanan" class="form-label">Status Pesanan</label>
                            <select class="form-select" id="edit_status_pesanan" name="status_pesanan" required>
                                <option value="Menunggu">Menunggu</option>
                                <option value="Diproses">Diproses</option>
                                <option value="Selesai">Selesai</option>
                                <option value="Dibatalkan">Dibatalkan</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Pilih Menu dan Jumlah</label>
                            <div id="edit_menu_list">
                                <!-- Menu items checkboxes and quantity inputs will be populated here -->
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const editButtons = document.querySelectorAll('.edit-btn');
            const editPesananModal = new bootstrap.Modal(document.getElementById('editPesananModal'));

            // Fetch all menu items for populating edit modal
            const allMenuItems = [];
            <?php
            $menu_query = "SELECT id_menu, nama_menu FROM menu";
            $menu_result = $conn->query($menu_query);
            if ($menu_result && $menu_result->num_rows > 0) {
                while ($menu_row = $menu_result->fetch_assoc()) {
                    $id_menu_js = htmlspecialchars($menu_row['id_menu']);
                    $nama_menu_js = htmlspecialchars($menu_row['nama_menu']);
                    echo "allMenuItems.push({id: '$id_menu_js', name: '$nama_menu_js'});\n";
                }
            }
            ?>

            editButtons.forEach(button => {
                button.addEventListener('click', function () {
                    const id = this.getAttribute('data-id');
                    const nomorMeja = this.getAttribute('data-nomor-meja');
                    const namaPelanggan = this.getAttribute('data-nama-pelanggan');
                    const statusPesanan = this.getAttribute('data-status-pesanan');

                    // Fetch menu items and quantities for this order via AJAX or embed in data attributes
                    // For simplicity, we will fetch via AJAX here

                    fetch(`get_pesanan_detail.php?id=${id}`)
                        .then(response => response.json())
                        .then(data => {
                            // Populate the edit modal fields
                            document.getElementById('edit_id_pesanan').value = id;
                            document.getElementById('edit_nomor_meja').value = nomorMeja;
                            document.getElementById('edit_nama_pelanggan').value = namaPelanggan;
                            document.getElementById('edit_status_pesanan').value = statusPesanan;

                            // Populate menu list with checkboxes and quantities
                            const menuListDiv = document.getElementById('edit_menu_list');
                            menuListDiv.innerHTML = '';
                            allMenuItems.forEach(menuItem => {
                                const isChecked = data.menu_items.some(mi => mi.id_menu == menuItem.id);
                                const quantityObj = data.menu_items.find(mi => mi.id_menu == menuItem.id);
                                const quantity = quantityObj ? quantityObj.jumlah : 1;

                                const div = document.createElement('div');
                                div.className = 'input-group mb-2';

                                const divCheckbox = document.createElement('div');
                                divCheckbox.className = 'input-group-text';

                                const checkbox = document.createElement('input');
                                checkbox.type = 'checkbox';
                                checkbox.className = 'form-check-input mt-0';
                                checkbox.name = 'menu_items[]';
                                checkbox.value = menuItem.id;
                                checkbox.checked = isChecked;

                                divCheckbox.appendChild(checkbox);

                                const inputText = document.createElement('input');
                                inputText.type = 'text';
                                inputText.className = 'form-control';
                                inputText.value = menuItem.name;
                                inputText.readOnly = true;

                                const inputNumber = document.createElement('input');
                                inputNumber.type = 'number';
                                inputNumber.className = 'form-control';
                                inputNumber.name = `jumlah[${menuItem.id}]`;
                                inputNumber.min = 1;
                                inputNumber.value = quantity;

                                div.appendChild(divCheckbox);
                                div.appendChild(inputText);
                                div.appendChild(inputNumber);

                                menuListDiv.appendChild(div);
                            });

                            // Show the edit modal
                            editPesananModal.show();
                        })
                        .catch(error => {
                            console.error('Error fetching order details:', error);
                            alert('Failed to load order details for editing.');
                        });
                });
            });
        });
    </script>

    <!-- bundle -->
    <script src="../assets/js/vendor.min.js"></script>
    <script src="../assets/js/app.min.js"></script>

    <!-- third party js -->
    <script src="../assets/js/vendor/apexcharts.min.js"></script>
    <script src="../assets/js/vendor/jquery-jvectormap-1.2.2.min.js"></script>
    <script src="../assets/js/vendor/jquery-jvectormap-world-mill-en.js"></script>
    <!-- third party js ends -->

    <!-- demo app -->
    <script src="../assets/js/pages/demo.dashboard.js"></script>
    <!-- end demo js-->
</body>
</html>
