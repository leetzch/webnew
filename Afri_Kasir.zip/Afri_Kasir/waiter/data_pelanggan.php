<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}
require 'db.php';

$user_id = $_SESSION['user_id'];
$username = 'Afri Maulizuardi'; // default username

// Fetch pelanggan data
$pelanggan_result = $conn->query("SELECT id_pelanggan, nama_pelanggan, jenis_kelamin, no_hp, alamat FROM pelanggan ORDER BY id_pelanggan ASC");

// Fetch username from user table
$stmt = $conn->prepare('SELECT username FROM user WHERE id_user = ?');
$stmt->bind_param('i', $user_id);
$stmt->execute();
$stmt->bind_result($db_username);
if ($stmt->fetch()) {
    $username = $db_username;
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Data Pelanggan | AfriKasir - LSP</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="../assets/images/favicon.ico" />
    <link href="../assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="../assets/css/app.min.css" rel="stylesheet" type="text/css" id="light-style" />
    <link href="../assets/css/app-dark.min.css" rel="stylesheet" type="text/css" id="dark-style" />
</head>

<body class="loading" data-layout-config='{"leftSideBarTheme":"dark","layoutBoxed":false, "leftSidebarCondensed":false, "leftSidebarScrollable":false,"darkMode":false, "showRightSidebarOnStart": true}'>
    <div class="wrapper">
        <div class="leftside-menu">
            <a href="index.php" class="logo text-center logo-light">
                <span class="logo-lg">
                    <img src="../assets/images/logo.png" alt="" height="16" />
                </span>
                <span class="logo-sm">
                    <img src="../assets/images/logo_sm.png" alt="" height="16" />
                </span>
            </a>
            <div class="h-100" id="leftside-menu-container" data-simplebar="">
                <ul class="side-nav">
                    <li class="side-nav-title side-nav-item">Navigation</li>
                    <li class="side-nav-item">
                        <a data-bs-toggle="collapse" href="#sidebarDashboards" aria-expanded="false" aria-controls="sidebarDashboards" class="side-nav-link">
                            <i class="uil-home-alt"></i>
                            <span class="badge bg-success float-end">4</span>
                            <span> Dashboards </span>
                        </a>
                    </li>
                    <li class="side-nav-title side-nav-item">Apps</li>
                    <li class="side-nav-item">
                        <a href="data_pelanggan.php" class="side-nav-link">
                            <i class="uil-calender"></i>
                            <span> Data Pelanggan </span>
                        </a>
                    </li>
                    <li class="side-nav-item">
                        <a href="data_pesanan.php" class="side-nav-link">
                            <i class="uil-comments-alt"></i>
                            <span> Data Pesanan </span>
                        </a>
                    </li>
                    <li class="side-nav-item">
                        <a href="data_menu.php" class="side-nav-link">
                            <i class="uil-comments-alt"></i>
                            <span> Data Menu </span>
                        </a>
                    </li>
                    <li class="side-nav-item">
                        <a href="logout.php" class="side-nav-link">
                            <i class="mdi mdi-logout me-1"></i>
                            <span> Log Out </span>
                        </a>
                    </li>
                </ul>
                <div class="clearfix"></div>
            </div>
        </div>

        <div class="content-page">
            <div class="content">
                <div class="navbar-custom">
                    <ul class="list-unstyled topbar-menu float-end mb-0">
                        <li class="dropdown notification-list d-lg-none">
                            <a class="nav-link dropdown-toggle arrow-none" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                <i class="dripicons-search noti-icon"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-animated dropdown-lg p-0">
                                <form class="p-3">
                                    <input type="text" class="form-control" placeholder="Search ..." aria-label="Recipient's username" />
                                </form>
                            </div>
                        </li>
                        <li class="dropdown notification-list">
                            <a class="nav-link dropdown-toggle nav-user arrow-none me-0" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                <span class="account-user-avatar">
                                    <img src="../assets/images/users/avatar-1.jpg" alt="user-image" class="rounded-circle" />
                                </span>
                                <span>
                                    <span class="account-user-name"><?php echo htmlspecialchars($username ?? ''); ?></span>
                                    <span class="account-position">Founder</span>
                                </span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end dropdown-menu-animated topbar-dropdown-menu profile-dropdown">
                                <div class=" dropdown-header noti-title">
                                    <h6 class="text-overflow m-0">Welcome !</h6>
                                </div>
                                <a href="logout.php" class="dropdown-item notify-item">
                                    <i class="mdi mdi-logout me-1"></i>
                                    <span>Logout</span>
                                </a>
                            </div>
                        </li>
                    </ul>
                </div>

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <h4 class="page-title">Dashboard</h4>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addPelangganModal">
                            Tambah Pelanggan
                        </button>
                    </div>

                    <!-- Modal Tambah Pelanggan -->
                    <div class="modal fade" id="addPelangganModal" tabindex="-1" aria-labelledby="addPelangganModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form action="proses_tambah_pelanggan.php" method="POST">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="addPelangganModalLabel">Tambah Pelanggan</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="mb-3">
                                            <label for="nama_pelanggan" class="form-label">Nama Pelanggan</label>
                                            <input type="text" class="form-control" id="nama_pelanggan" name="nama_pelanggan" required />
                                        </div>
                                        <div class="mb-3">
                                            <label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
                                            <select class="form-select" id="jenis_kelamin" name="jenis_kelamin" required>
                                            <option value="1">Laki-Laki</option>
                                            <option value="0">Perempuan</option>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label for="nomor_hp" class="form-label">Nomor HP</label>
                                            <input type="text" class="form-control" id="nomor_hp" name="nomor_hp" required />
                                        </div>
                                        <div class="mb-3">
                                            <label for="alamat" class="form-label">Alamat</label>
                                            <input type="text" class="form-control" id="alamat" name="alamat" required />
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Save</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <table id="pelanggan-datatable" class="table table-bordered table-striped dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Pelanggan</th>
                                <th>Jenis Kelamin</th>
                                <th>Nomor HP</th>
                                <th>Alamat
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($pelanggan_result && $pelanggan_result->num_rows > 0) {
                               
                                $no = 1;
                                while ($row = $pelanggan_result->fetch_assoc()) {
                                    if($row['jenis_kelamin'] == 0){
                                        $row['jenis_kelamin'] = "Perempuan";
                                    }else{
                                        $row['jenis_kelamin'] = "Laki-Laki";
                                    }
                                    echo "<tr>";
                                    echo "<td>" . $no++ . "</td>";
                                    echo "<td>" . htmlspecialchars($row['nama_pelanggan']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['jenis_kelamin']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['no_hp']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['alamat']) . "</td>";

                                    echo "<td>";
                                    echo "<button type='button' class='btn btn-sm btn-primary me-1 edit-btn' data-id='" . htmlspecialchars($row['id_pelanggan']) . "' data-nama-pelanggan='" . htmlspecialchars($row['nama_pelanggan']) . "' data-jenis-kelamin='" . htmlspecialchars($row['jenis_kelamin']) . "' data-nomor-hp='" . htmlspecialchars($row['no_hp']) . "' data-alamat='" . htmlspecialchars($row['alamat']) . "'>Edit</button>";
                                    echo "<a href='delete_pelanggan.php?id=" . urlencode($row['id_pelanggan']) . "' class='btn btn-sm btn-danger' onclick=\"return confirm('Are you sure you want to delete this pelanggan?');\">Hapus</a>";
                                    echo "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='4'>No data found</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="rightbar-overlay"></div>

    <!-- Modal Edit Pelanggan -->
    <div class="modal fade" id="editPelangganModal" tabindex="-1" aria-labelledby="editPelangganModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="proses_edit_pelanggan.php" method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editPelangganModalLabel">Edit Pelanggan</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" id="edit_id_pelanggan" name="id_pelanggan" />
                        <div class="mb-3">
                            <label for="edit_nama_pelanggan" class="form-label">Nama Pelanggan</label>
                            <input type="text" class="form-control" id="edit_nama_pelanggan" name="nama_pelanggan" required />
                        </div>
                        <div class="mb-3">
                            <label for="edit_jenis_kelamin" class="form-label">Jenis Kelamin</label>
                            <select class="form-select" id="edit_jenis_kelamin" name="jenis_kelamin" required>
                            <option value="1">Laki-Laki</option>
                            <option value="0">Perempuan</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="edit_nomor_hp" class="form-label">Nomor HP</label>
                            <input type="text" class="form-control" id="edit_nomor_hp" name="nomor_hp" required />
                        </div>
                        <div class="mb-3">
                            <label for="edit_alamat" class="form-label">Alamat</label>
                            <input type="text" class="form-control" id="edit_alamat" name="alamat" required />
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const editButtons = document.querySelectorAll('.edit-btn');
            const editPelangganModal = new bootstrap.Modal(document.getElementById('editPelangganModal'));

            editButtons.forEach(button => {
                button.addEventListener('click', function () {
                    const id = this.getAttribute('data-id');
                    const namaPelanggan = this.getAttribute('data-nama-pelanggan');
                    const jenisKelamin = this.getAttribute('data-jenis-kelamin');
                    const nomorHp = this.getAttribute('data-nomor-hp');
                    const alamat = this.getAttribute('data-alamat');

                    document.getElementById('edit_id_pelanggan').value = id;
                    document.getElementById('edit_nama_pelanggan').value = namaPelanggan;
                    document.getElementById('edit_jenis_kelamin').value = jenisKelamin;
                    document.getElementById('edit_nomor_hp').value = nomorHp;
                    document.getElementById('edit_alamat').value = alamat;

                    editPelangganModal.show();
                });
            });
        });
    </script>

    <script src="../assets/js/vendor.min.js"></script>
    <script src="../assets/js/app.min.js"></script>
</body>

</html>
