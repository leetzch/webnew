<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}
require 'db.php';

if (isset($_GET['id'])) {
    $id_pelanggan = $_GET['id'];

    $stmt = $conn->prepare("DELETE FROM pelanggan WHERE id_pelanggan = ?");
    $stmt->bind_param("i", $id_pelanggan);
    if ($stmt->execute()) {
        $stmt->close();
        header("Location: data_pelanggan.php");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
} else {
    header("Location: data_pelanggan.php");
    exit();
}
?>
