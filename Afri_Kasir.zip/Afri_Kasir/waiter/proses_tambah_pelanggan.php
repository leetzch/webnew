<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_pelanggan = $_POST['nama_pelanggan'] ?? '';
    $jenis_kelamin = $_POST['jenis_kelamin'] ?? '';
    $nomor_hp = $_POST['nomor_hp'] ?? '';
    $alamat = $_POST['alamat'] ?? '';

    if ($nama_pelanggan && $nomor_hp) {
        $stmt = $conn->prepare("INSERT INTO pelanggan (nama_pelanggan, jenis_kelamin, no_hp, alamat) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $nama_pelanggan, $jenis_kelamin, $nomor_hp, $alamat);
        if ($stmt->execute()) {
            $stmt->close();
            header("Location: data_pelanggan.php");
            exit();
        } else {
            echo "Error: " . $conn->error;
        }
    } else {
        echo "Nama Pelanggan, Jenis Kelamin, Nomor HP, Alamat are required.";
    }
} else {
    header("Location: data_pelanggan.php");
    exit();
}
?>
