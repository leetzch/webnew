<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_pelanggan = $_POST['id_pelanggan'] ?? '';
    $nama_pelanggan = $_POST['nama_pelanggan'] ?? '';
    $jenis_kelamin = $_POST['jenis_kelamin'] ?? '';
    $nomor_hp = $_POST['nomor_hp'] ?? '';
    $alamat = $_POST['alamat'] ?? '';

    if ($id_pelanggan && $nama_pelanggan && $nomor_hp) {
        $stmt = $conn->prepare("UPDATE pelanggan SET nama_pelanggan = ?, jenis_kelamin = ?, no_hp = ?, alamat = ? WHERE id_pelanggan = ?");
        $stmt->bind_param("ssssi", $nama_pelanggan, $jenis_kelamin, $nomor_hp, $alamat, $id_pelanggan);
        if ($stmt->execute()) {
            $stmt->close();
            header("Location: data_pelanggan.php");
            exit();
        } else {
            echo "Error: " . $conn->error;
        }
    } else {
        echo "All fields are required.";
    }
} else {
    header("Location: data_pelanggan.php");
    exit();
}
?>
