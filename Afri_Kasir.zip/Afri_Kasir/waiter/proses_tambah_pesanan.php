<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}
require 'db.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nomor_meja = $_POST['nomor_meja'];
    $nama_pelanggan = $_POST['nama_pelanggan'];
    $menu_items = $_POST['menu_items'];
    $jumlah_items = $_POST['jumlah']; // New array for quantities

    // Start a transaction
    $conn->begin_transaction();

    try {
        // Get id_meja from nomor_meja
        $stmt_meja = $conn->prepare("SELECT id_meja FROM meja WHERE nomor_meja = ?");
        $stmt_meja->bind_param("s", $nomor_meja);
        $stmt_meja->execute();
        $stmt_meja->bind_result($id_meja);
        if (!$stmt_meja->fetch()) {
            throw new Exception("Nomor meja tidak ditemukan.");
        }
        $stmt_meja->close();

        $stmt_status = $conn->prepare("SELECT status_pesanan FROM pesanan WHERE id_meja = ?");
        $stmt_status->bind_param("s", $id_meja);
        $stmt_status->execute();

        // Mengambil hasil query
        $result = $stmt_status->get_result();
        if ($result->num_rows > 0) {
            // Menampilkan semua hasil dalam bentuk array asosiatif
            while ($row = $result->fetch_assoc()) {
                var_dump($row); // Menampilkan setiap baris data
                $status_pesanan = $row['status_pesanan'];
                echo "Status pesanan: " . $status_pesanan . "<br>";
            }
        } else {
            echo "Status pesanan tidak ditemukan.";
        }

        $stmt_status->close();

        // Mengecek status pesanan (misalnya, hanya mengecek satu status terakhir yang ditemukan)
        if ($status_pesanan == "Menunggu") {
            // Redirect jika pesanan sudah selesai
            header("Location: data_pesanan.php?error=duplicate_entry");
            exit;
        }





        // Get id_pelanggan from nama_pelanggan
        $stmt_pelanggan = $conn->prepare("SELECT id_pelanggan FROM pelanggan WHERE nama_pelanggan = ?");
        $stmt_pelanggan->bind_param("s", $nama_pelanggan);
        $stmt_pelanggan->execute();
        $stmt_pelanggan->bind_result($id_pelanggan);
        if (!$stmt_pelanggan->fetch()) {
            throw new Exception("Nama pelanggan tidak ditemukan.");
        }
        $stmt_pelanggan->close();

        // Insert the new order with obtained ids, default status 'Menunggu', id_user and current date
        $default_status = 'Menunggu';
        $id_user = $_SESSION['user_id'];
        $tanggal_pesanan = date('Y-m-d H:i:s');


        $stmt = $conn->prepare("INSERT INTO pesanan (id_meja, id_pelanggan, status_pesanan, id_user, tanggal_pesanan) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("iisis", $id_meja, $id_pelanggan, $default_status, $id_user, $tanggal_pesanan);
        $stmt->execute();
        $id_pesanan = $conn->insert_id; // Get the last inserted order ID

        // Calculate total quantity
        $total_jumlah = 0;
        foreach ($menu_items as $menu_id) {
            $jumlah = isset($jumlah_items[$menu_id]) ? (int)$jumlah_items[$menu_id] : 1;
            $total_jumlah += $jumlah;
        }

        // Update id_menu and jumlah fields in pesanan table
        $menu_ids_str = implode(',', $menu_items);
        $stmt_update_menu = $conn->prepare("UPDATE pesanan SET id_menu = ?, jumlah = ? WHERE id_pesanan = ?");
        $stmt_update_menu->bind_param("sii", $menu_ids_str, $total_jumlah, $id_pesanan);
        $stmt_update_menu->execute();

        // Insert each menu item into the detail_pesanan table with quantity
        foreach ($menu_items as $menu_id) {
            $jumlah = isset($jumlah_items[$menu_id]) ? (int)$jumlah_items[$menu_id] : 1;
            if ($jumlah < 1) {
                throw new Exception("Jumlah harus minimal 1 untuk menu item ID $menu_id.");
            }

            // Calculate subtotal
            $price_query = $conn->prepare("SELECT harga FROM menu WHERE id_menu = ?");
            $price_query->bind_param("i", $menu_id);
            $price_query->execute();
            $price_query->bind_result($harga);
            $price_query->fetch();
            $price_query->close();

            $subtotal = $harga * $jumlah;

            // Insert into detail_pesanan
            $stmt_detail = $conn->prepare("INSERT INTO detail_pesanan (id_pesanan, id_menu, jumlah, harga_satuan, subtotal) VALUES (?, ?, ?, ?, ?)");
            $stmt_detail->bind_param("iiiii", $id_pesanan, $menu_id, $jumlah, $harga, $subtotal);
            $stmt_detail->execute();
        }

        // Commit the transaction
        $conn->commit();
        header("Location: data_pesanan.php?success=pesanan_added");
    } catch (Exception $e) {
        // Rollback the transaction in case of error
        $conn->rollback();
        header("Location: data_pesanan.php?error=" . urlencode($e->getMessage()));
    }
} else {
    // Redirect if not a POST request
    header("Location: data_pesanan.php");
}
?>
