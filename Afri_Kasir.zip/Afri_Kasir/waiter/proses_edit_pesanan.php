<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_pesanan = $_POST['id_pesanan'];
    $nomor_meja = $_POST['nomor_meja'];
    $nama_pelanggan = $_POST['nama_pelanggan'];
    $status_pesanan = $_POST['status_pesanan'];
    $menu_items = $_POST['menu_items'] ?? [];
    $jumlah_items = $_POST['jumlah'] ?? [];

    // Start a transaction
    $conn->begin_transaction();

    try {
        // Get id_meja from nomor_meja
        $stmt_meja = $conn->prepare("SELECT id_meja FROM meja WHERE nomor_meja = ?");
        $stmt_meja->bind_param("s", $nomor_meja);
        $stmt_meja->execute();
        $stmt_meja->bind_result($id_meja);
        if (!$stmt_meja->fetch()) {
            throw new Exception("Nomor meja tidak ditemukan.");
        }
        $stmt_meja->close();

        // Get id_pelanggan from nama_pelanggan
        $stmt_pelanggan = $conn->prepare("SELECT id_pelanggan FROM pelanggan WHERE nama_pelanggan = ?");
        $stmt_pelanggan->bind_param("s", $nama_pelanggan);
        $stmt_pelanggan->execute();
        $stmt_pelanggan->bind_result($id_pelanggan);
        if (!$stmt_pelanggan->fetch()) {
            throw new Exception("Nama pelanggan tidak ditemukan.");
        }
        $stmt_pelanggan->close();

        // Calculate total quantity
        $total_jumlah = 0;
        foreach ($menu_items as $menu_id) {
            $jumlah = isset($jumlah_items[$menu_id]) ? (int)$jumlah_items[$menu_id] : 1;
            $total_jumlah += $jumlah;
        }

        // Update pesanan table
        $menu_ids_str = implode(',', $menu_items);
        $stmt_update = $conn->prepare("UPDATE pesanan SET id_meja = ?, id_pelanggan = ?, status_pesanan = ?, id_menu = ?, jumlah = ? WHERE id_pesanan = ?");
        $stmt_update->bind_param("iissii", $id_meja, $id_pelanggan, $status_pesanan, $menu_ids_str, $total_jumlah, $id_pesanan);
        $stmt_update->execute();

        // Delete existing detail_pesanan for this order
        $stmt_delete = $conn->prepare("DELETE FROM detail_pesanan WHERE id_pesanan = ?");
        $stmt_delete->bind_param("i", $id_pesanan);
        $stmt_delete->execute();

        // Insert new detail_pesanan entries
        foreach ($menu_items as $menu_id) {
            $jumlah = isset($jumlah_items[$menu_id]) ? (int)$jumlah_items[$menu_id] : 1;
            if ($jumlah < 1) {
                throw new Exception("Jumlah harus minimal 1 untuk menu item ID $menu_id.");
            }

            // Calculate subtotal
            $price_query = $conn->prepare("SELECT harga FROM menu WHERE id_menu = ?");
            $price_query->bind_param("i", $menu_id);
            $price_query->execute();
            $price_query->bind_result($harga);
            $price_query->fetch();
            $price_query->close();

            $subtotal = $harga * $jumlah;

            // Insert into detail_pesanan
            $stmt_detail = $conn->prepare("INSERT INTO detail_pesanan (id_pesanan, id_menu, jumlah, harga_satuan, subtotal) VALUES (?, ?, ?, ?, ?)");
            $stmt_detail->bind_param("iiiii", $id_pesanan, $menu_id, $jumlah, $harga, $subtotal);
            $stmt_detail->execute();
        }

        // Commit transaction
        $conn->commit();
        header("Location: data_pesanan.php?success=pesanan_edited");
    } catch (Exception $e) {
        $conn->rollback();
        header("Location: data_pesanan.php?error=" . urlencode($e->getMessage()));
    }
} else {
    // Redirect if not a POST request
    header("Location: data_pesanan.php");
}
?>
