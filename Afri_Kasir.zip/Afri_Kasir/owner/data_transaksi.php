<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}
require 'db.php';

$user_id = $_SESSION['user_id'];
$username = 'Afri Maulizuardi'; // default username

$stmt = $conn->prepare('SELECT username FROM user WHERE id_user = ?');
$stmt->bind_param('i', $user_id);
$stmt->execute();
$stmt->bind_result($db_username);
if ($stmt->fetch()) {
    $username = $db_username;
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Data Transaksi | AfriKasir - LSP</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../assets/images/favicon.ico">
    <link href="../assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="../assets/css/app.min.css" rel="stylesheet" type="text/css" id="light-style" />
    <link href="../assets/css/app-dark.min.css" rel="stylesheet" type="text/css" id="dark-style" />
</head>

<body class="loading" data-layout-config='{"leftSideBarTheme":"dark","layoutBoxed":false,"leftSidebarCondensed":false,"leftSidebarScrollable":false,"darkMode":false,"showRightSidebarOnStart":true}'>
    <div class="wrapper">
        <div class="leftside-menu">
            <a href="index.php" class="logo text-center logo-light">
                <span class="logo-lg">
                    <img src="../assets/images/logo.png" alt="" height="16" />
                </span>
                <span class="logo-sm">
                    <img src="../assets/images/logo_sm.png" alt="" height="16" />
                </span>
            </a>
            <div class="h-100" id="leftside-menu-container" data-simplebar="">

                <!--- Sidemenu -->
                <ul class="side-nav">

                    <li class="side-nav-title side-nav-item">Navigation</li>

                    <li class="side-nav-item">
                        <a data-bs-toggle="collapse" href="index.php" aria-expanded="false" aria-controls="sidebarDashboards" class="side-nav-link">
                            <i class="uil-home-alt"></i>
                            <span class="badge bg-success float-end">4</span>
                            <span> Dashboards </span>
                        </a>
                        
                    </li>

                    <li class="side-nav-title side-nav-item">Apps</li>
                    
                    <li class="side-nav-item">
                        <a href="data_transaksi.php" class="side-nav-link">
                            <i class="uil-comments-alt"></i>
                            <span> Data Transaksi </span>
                        </a>
                    </li>
                    
                    <li class="side-nav-item">
                        <a href="logout.php" class="side-nav-link">
                            <i class="mdi mdi-logout me-1"></i>
                            <span> Log Out </span>
                        </a>
                    </li>
                </ul>
                <div class="clearfix"></div>
            </div>
        </div>

        <div class="content-page">
            <div class="content">
                <div class="navbar-custom">
                    <ul class="list-unstyled topbar-menu float-end mb-0">
                        <li class="dropdown notification-list d-lg-none">
                            <a class="nav-link dropdown-toggle arrow-none" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                <i class="dripicons-search noti-icon"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-animated dropdown-lg p-0">
                                <form class="p-3">
                                    <input type="text" class="form-control" placeholder="Search ..." aria-label="Recipient's username" />
                                </form>
                            </div>
                        </li>
                        <li class="dropdown notification-list">
                            <a class="nav-link dropdown-toggle nav-user arrow-none me-0" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                <span class="account-user-avatar">
                                    <img src="../assets/images/users/avatar-1.jpg" alt="user-image" class="rounded-circle" />
                                </span>
                                <span>
                                    <span class="account-user-name"><?php echo htmlspecialchars($username ?? ''); ?></span>
                                    <span class="account-position">Founder</span>
                                </span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end dropdown-menu-animated topbar-dropdown-menu profile-dropdown">
                                <div class=" dropdown-header noti-title">
                                    <h6 class="text-overflow m-0">Welcome !</h6>
                                </div>
                                <a href="logout.php" class="dropdown-item notify-item">
                                    <i class="mdi mdi-logout me-1"></i>
                                    <span>Logout</span>
                                </a>
                            </div>
                        </li>
                    </ul>
                </div>

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <h4 class="page-title">Data Transaksi</h4>
                            </div>
                        </div>
                    </div>

                            <table id="transaksi-datatable" class="table table-bordered table-striped dt-responsive nowrap w-100">
                                <thead>
                                    <tr>
                                        <th>ID Pesanan</th>
                                        <th>Nama Pesanan</th>
                                        <th>Total Pesanan</th>
                                        <th>Bayar</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $query = "SELECT p.id_pesanan, p.status_pesanan, t.id_transaksi, GROUP_CONCAT(m.nama_menu SEPARATOR ', ') AS nama_pesanan, p.jumlah AS total_pesanan, t.bayar
                                              FROM pesanan p
                                              INNER JOIN detail_pesanan dp ON p.id_pesanan = dp.id_pesanan
                                              INNER JOIN menu m ON dp.id_menu = m.id_menu
                                              INNER JOIN transaksi t ON p.id_pesanan = t.id_pesanan
                                              WHERE p.status_pesanan = 'Selesai'
                                              GROUP BY p.id_pesanan, t.id_transaksi, t.bayar";
                                    $result = $conn->query($query);
                                    if ($result && $result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            echo "<tr>";
                                            echo "<td>" . htmlspecialchars($row['id_pesanan']) . "</td>";
                                            echo "<td>" . htmlspecialchars($row['nama_pesanan']) . "</td>";
                                            echo "<td>" . htmlspecialchars($row['total_pesanan']) . "</td>";
                                            echo "<td>" . htmlspecialchars($row['bayar']) . "</td>";
                                            echo "<td>";
                                            echo "<a href='data_transaksi_detail.php?id=" . urlencode($row['id_pesanan']) . "' target='_blank' class='btn btn-sm btn-info'>Generate Laporan</a>";
                                            echo "</td>";
                                            echo "</tr>";
                                        }
                                    } else {
                                        echo "<tr><td colspan='5'>No data found</td></tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                </div>
            </div>
        </div>
    </div>

    <div class="rightbar-overlay"></div>

    <script src="../assets/js/vendor.min.js"></script>
    <script src="../assets/js/app.min.js"></script>
</body>
</html>
