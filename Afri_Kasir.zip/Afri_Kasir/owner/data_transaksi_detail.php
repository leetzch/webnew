<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}
require 'db.php';

$tanggal_pesanan = date('Y-m-d H:i:s');


$user_id = $_SESSION['user_id'];
$username = 'Afri Maulizuardi'; // default username

$stmt = $conn->prepare('SELECT username FROM user WHERE id_user = ?');
$stmt->bind_param('i', $user_id);
$stmt->execute();
$stmt->bind_result($db_username);
if ($stmt->fetch()) {
    $username = $db_username;
}
$stmt->close();

$id_pesanan = $_GET['id'] ?? null;
if (!$id_pesanan) {
    echo "ID Pesanan is required.";
    exit;
}

// Get nama pelanggan for the pesanan
$nama_pelanggan = '';
$pelanggan_query = "SELECT pl.nama_pelanggan FROM pesanan p INNER JOIN pelanggan pl ON p.id_pelanggan = pl.id_pelanggan WHERE p.id_pesanan = ?";
$stmt_pelanggan = $conn->prepare($pelanggan_query);
$stmt_pelanggan->bind_param('i', $id_pesanan);
$stmt_pelanggan->execute();
$stmt_pelanggan->bind_result($nama_pelanggan);
$stmt_pelanggan->fetch();
$stmt_pelanggan->close();

$query = "SELECT p.id_pesanan, p.status_pesanan, t.id_transaksi, GROUP_CONCAT(m.nama_menu SEPARATOR ', ') AS nama_pesanan, p.jumlah AS total_pesanan, t.bayar, t.uang
          FROM pesanan p
          INNER JOIN detail_pesanan dp ON p.id_pesanan = dp.id_pesanan
          INNER JOIN menu m ON dp.id_menu = m.id_menu
          INNER JOIN transaksi t ON p.id_pesanan = t.id_pesanan
          WHERE p.id_pesanan = ? AND p.status_pesanan = 'Selesai'
          GROUP BY p.id_pesanan, t.id_transaksi, t.bayar, t.uang";
$stmt = $conn->prepare($query);
$stmt->bind_param('i', $id_pesanan);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Detail Data Transaksi | AfriKasir - LSP</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="../assets/images/favicon.ico" />
    <link href="../assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="../assets/css/app.min.css" rel="stylesheet" type="text/css" id="light-style" />
    <link href="../assets/css/app-dark.min.css" rel="stylesheet" type="text/css" id="dark-style" />
</head>

<body class="loading" data-layout-config='{"leftSideBarTheme":"dark","layoutBoxed":false,"leftSidebarCondensed":false,"leftSidebarScrollable":false,"darkMode":false,"showRightSidebarOnStart":true}'>
    <div class="wrapper">
        <div class="leftside-menu">
            <a href="index.php" class="logo text-center logo-light">
                <span class="logo-lg">
                    <img src="../assets/images/logo.png" alt="" height="16" />
                </span>
                <span class="logo-sm">
                    <img src="../assets/images/logo_sm.png" alt="" height="16" />
                </span>
            </a>
            <div class="h-100" id="leftside-menu-container" data-simplebar="">
                <ul class="side-nav">
                    <li class="side-nav-title side-nav-item">Navigation</li>
                    <li class="side-nav-item">
                        <a href="index.php" class="side-nav-link">
                            <i class="uil-home-alt"></i>
                            <span> Dashboards </span>
                        </a>
                    </li>
                    <li class="side-nav-title side-nav-item">Apps</li>
                    
                    <li class="side-nav-item">
                        <a href="data_transaksi.php" class="side-nav-link">
                            <i class="uil-calender"></i>
                            <span> Data Transaksi </span>
                        </a>
                    </li>
                    <li class="side-nav-item">
                        <a href="logout.php" class="side-nav-link">
                            <i class="mdi mdi-logout me-1"></i>
                            <span> Log Out </span>
                        </a>
                    </li>
                </ul>
                <div class="clearfix"></div>
            </div>
        </div>

        <div class="content-page">
            <div class="content">
                <div class="navbar-custom">
                    <ul class="list-unstyled topbar-menu float-end mb-0">
                        <li class="dropdown notification-list d-lg-none">
                            <a class="nav-link dropdown-toggle arrow-none" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                <i class="dripicons-search noti-icon"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-animated dropdown-lg p-0">
                                <form class="p-3">
                                    <input type="text" class="form-control" placeholder="Search ..." aria-label="Recipient's username" />
                                </form>
                            </div>
                        </li>
                        <li class="dropdown notification-list">
                            <a class="nav-link dropdown-toggle nav-user arrow-none me-0" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                <span class="account-user-avatar">
                                    <img src="../assets/images/users/avatar-1.jpg" alt="user-image" class="rounded-circle" />
                                </span>
                                <span>
                                    <span class="account-user-name"><?php echo htmlspecialchars($username ?? ''); ?></span>
                                    <span class="account-position">Founder</span>
                                </span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end dropdown-menu-animated topbar-dropdown-menu profile-dropdown">
                                <div class=" dropdown-header noti-title">
                                    <h6 class="text-overflow m-0">Welcome !</h6>
                                </div>
                                <a href="logout.php" class="dropdown-item notify-item">
                                    <i class="mdi mdi-logout me-1"></i>
                                    <span>Logout</span>
                                </a>
                            </div>
                        </li>
                    </ul>
                </div>

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <h4 class="page-title">Detail Pesanan</h4>
                            </div>
                        </div>
                    </div>

                    <?php
                    // Fetch detail pesanan items for the given id_pesanan
                    $detail_query = "SELECT dp.id_menu, m.nama_menu, dp.jumlah
                                     FROM detail_pesanan dp
                                     INNER JOIN menu m ON dp.id_menu = m.id_menu
                                     WHERE dp.id_pesanan = ?";
                    $stmt_detail = $conn->prepare($detail_query);
                    $stmt_detail->bind_param('i', $id_pesanan);
                    $stmt_detail->execute();
                    $detail_result = $stmt_detail->get_result();
                    ?>
                    <h5>Detail Items for Pesanan ID: <?php echo htmlspecialchars($id_pesanan); ?></h5>
                    <h5>Atas nama : <?php echo htmlspecialchars($nama_pelanggan); ?></h5>
                    <h5>Tanggal : <?php echo htmlspecialchars($tanggal_pesanan); ?></h5>

                    <table id="detail-pesanan-items" class="table table-bordered table-striped dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <th>ID Menu</th>
                                <th>Nama Menu</th>
                                <th>Jumlah</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $total_jumlah = 0;
                            if ($detail_result && $detail_result->num_rows > 0) {
                                while ($item = $detail_result->fetch_assoc()) {
                                    $total_jumlah += $item['jumlah'];
                                    echo "<tr>";
                                    echo "<td>" . htmlspecialchars($item['id_menu']) . "</td>";
                                    echo "<td>" . htmlspecialchars($item['nama_menu']) . "</td>";
                                    echo "<td>" . htmlspecialchars($item['jumlah']) . "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='3'>No detail items found</td></tr>";
                            }
                            ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <?php
                                    // Display uang pelanggan and kembalian if transaction exists
                                    if ($result && $result->num_rows > 0) {
                                        $transaksi = $result->fetch_assoc();
                                        $uang = $transaksi['uang'] ?? 0;
                                        $bayar = $transaksi['bayar'] ?? 0;
                                        $kembalian = $uang - $bayar;
                                        
                                    }
                                ?>
                                <th colspan="2">Uang Pelanggan</th>
                                <th>Rp <?php echo number_format($uang, 3, ',', '.'); ?></th>
                            </tr>
                            <tr>
                                <th colspan="2">Uang Kembalian</th>
                                <th>Rp <?php echo number_format($kembalian, 3, ',', '.'); ?></th>
                            </tr>
                        </tfoot>
                        
                        <tfoot>
                            <tr>
                            <?php
                                // Calculate total harga from detail_pesanan subtotal for the given id_pesanan
                                $total_harga_query = "SELECT SUM(subtotal) AS total_harga FROM detail_pesanan WHERE id_pesanan = ?";
                                $stmt_total = $conn->prepare($total_harga_query);
                                $stmt_total->bind_param('i', $id_pesanan);
                                $stmt_total->execute();
                                $stmt_total->bind_result($total_harga);
                                $stmt_total->fetch();
                                $stmt_total->close();
                            ?>
                                <th colspan="2">Total Harga</th>
                                <th>Rp <?php echo number_format($total_harga ?? 0, 3, ',', '.'); ?></th>
                            </tr>
                        </tfoot>
                        <tfoot>
                            <tr>
                                <th colspan="2">Total Jumlah</th>
                                <th><?php echo $total_jumlah; ?></th>
                            </tr>
                        </tfoot>
                        
                    </table>

                    <button onclick="window.print()" class="btn btn-primary mt-3">Print Laporan</button>

                    

            


                </div>
            </div>
        </div>
    </div>

    <div class="rightbar-overlay"></div>

    <script src="../assets/js/vendor.min.js"></script>
    <script src="../assets/js/app.min.js"></script>
</body>

</html>
