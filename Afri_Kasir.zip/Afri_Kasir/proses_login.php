<?php
session_start();
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        header('Location: login.php?error=emptyfields');
        exit();
    }

    $stmt = $conn->prepare('SELECT id_user, username, password, role FROM user WHERE username = ?');
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($user = $result->fetch_assoc()) {
        // Verifikasi password
        if (password_verify($password, $user['password'])) {
            // Password bener, set session dan redirect sesuai role
            $_SESSION['user_id'] = $user['id_user'];
            $_SESSION['user_username'] = $user['username'];
            $_SESSION['user_role'] = $user['role']; // Set user role in session

            // Redirect sesuai role
            if ($user['role'] === 'Admin') {
                header('Location: admin/index.php');
            } elseif ($user['role'] === 'Owner') {
                header('Location: owner/index.php');
            } elseif ($user['role'] === 'Waiter') {
                header('Location: waiter/index.php');
            } elseif ($user['role'] === 'Kasir') {
                header('Location: kasir/index.php');
            } else {
                header('Location: login.php?error=invalidrole');
            }
            exit();
        } else {
            // Password Salah
            header('Location: login.php?error=wrongpassword');
            exit();
        }
    } else {
        // User tidak ditemukan
        header('Location: login.php?error=nouser');
        exit();
    }
} else {
    // Bukan request post (mencoba GET aja dari URL)
    header('Location: login.php');
    exit();
}
?>
