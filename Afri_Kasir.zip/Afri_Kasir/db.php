<?php
$host = "localhost";
$username = "root";
$password = "";
$db = "afri_kasir";

$conn = mysqli_connect($host, $username, $password, $db) or die("koneksi gagal terhubung..");
?>